# Family Finance Tracker

A comprehensive family finance management application for Android.

## Features

- 👤 Multi-user support with admin approval
- 💰 Income and Expense tracking
- 🏦 EMI management
- 💸 Borrow/Lend tracking
- 📊 Dashboard with charts
- 🔍 Transaction history with search and filter
- 📁 Export to CSV/PDF/Excel
- 🔒 Secure login with password hashing
- 💾 Auto backup and restore

## Technologies Used

- Kotlin
- Android Jetpack (Room, ViewModel, LiveData)
- Coroutines
- Material Design 3
- MPAndroidChart

## Setup Instructions

1. Clone the repository
2. Open in Android Studio
3. Sync Gradle
4. Build and run

## Screenshots

[Add screenshots here]

## License

MIT License