package com.example.familyfinancetracker

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testCurrencyFormat() {
        val amount = 1000.0
        val formatted = "₹1,000.00"
        // Test currency formatting logic
    }

    @Test
    fun testDateParsing() {
        val timestamp = 1609459200000L // Jan 1, 2021
        // Test date parsing logic
    }
}