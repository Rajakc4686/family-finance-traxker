package com.example.familyfinancetracker.ui.add

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.example.familyfinancetracker.databinding.FragmentAddEmiBinding
import com.example.familyfinancetracker.data.EMI
import com.example.familyfinancetracker.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class AddEMIFragment : Fragment() {

    private var _binding: FragmentAddEmiBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddEmiBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupAddButton()
    }
    
    private fun setupAddButton() {
        binding.btnAddEmi.setOnClickListener {
            val bankName = binding.etEmiBank.text.toString().trim()
            val totalStr = binding.etEmiTotal.text.toString().trim()
            val monthlyStr = binding.etEmiMonthly.text.toString().trim()
            val monthsStr = binding.etEmiMonths.text.toString().trim()
            
            if (bankName.isEmpty() || totalStr.isEmpty() || monthlyStr.isEmpty() || monthsStr.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            val totalAmount = totalStr.toDoubleOrNull()
            val monthlyAmount = monthlyStr.toDoubleOrNull()
            val totalMonths = monthsStr.toIntOrNull()
            
            if (totalAmount == null || monthlyAmount == null || totalMonths == null) {
                Toast.makeText(requireContext(), "Please enter valid numbers", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            lifecycleScope.launch {
                val currentUser = viewModel.currentUser.value
                if (currentUser != null) {
                    val startDate = System.currentTimeMillis()
                    val emi = EMI(
                        userId = currentUser.id,
                        userName = currentUser.name,
                        bankName = bankName,
                        totalAmount = totalAmount,
                        monthlyAmount = monthlyAmount,
                        totalMonths = totalMonths,
                        startDate = startDate,
                        nextPaymentDate = startDate + (30 * 24 * 60 * 60 * 1000L)
                    )
                    viewModel.addEMI(emi)
                    Toast.makeText(requireContext(), "EMI added successfully", Toast.LENGTH_SHORT).show()
                    clearFields()
                }
            }
        }
    }
    
    private fun clearFields() {
        binding.etEmiBank.text.clear()
        binding.etEmiTotal.text.clear()
        binding.etEmiMonthly.text.clear()
        binding.etEmiMonths.text.clear()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}