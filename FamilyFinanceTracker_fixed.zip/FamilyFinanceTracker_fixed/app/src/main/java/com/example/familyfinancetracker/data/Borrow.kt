package com.example.familyfinancetracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "borrows")
data class Borrow(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val userName: String,
    val personName: String,
    val amount: Double,
    val date: Long,
    val returnDate: Long,
    val isReturned: Boolean = false,
    val returnedAmount: Double = 0.0,
    val remainingAmount: Double = 0.0,
    val interestRate: Double = 0.0,
    val interestAmount: Double = 0.0,
    val totalWithInterest: Double = 0.0,
    val purpose: String = "",
    val notes: String = "",
    val actualReturnDate: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
)