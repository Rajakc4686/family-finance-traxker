package com.example.familyfinancetracker.data

import kotlinx.coroutines.flow.Flow

class Repository(private val db: AppDatabase) {
    
    fun getAllUsers(): Flow<List<User>> = db.userDao().getAllUsers()
    suspend fun login(email: String, password: String): User? = db.userDao().login(email, password)
    suspend fun getUserByEmail(email: String): User? = db.userDao().getUserByEmail(email)
    suspend fun insertUser(user: User): Long = db.userDao().insertUser(user)
    suspend fun updateUser(user: User) = db.userDao().updateUser(user)
    suspend fun approveUser(userId: Int) = db.userDao().approveUser(userId)
    fun getPendingApprovals(): Flow<List<User>> = db.userDao().getPendingApprovals()
    
    fun getAllIncomes(): Flow<List<Income>> = db.incomeDao().getAllIncomes()
    fun getUserIncomes(userId: Int): Flow<List<Income>> = db.incomeDao().getUserIncomes(userId)
    suspend fun insertIncome(income: Income): Long = db.incomeDao().insertIncome(income)
    suspend fun updateIncome(income: Income) = db.incomeDao().updateIncome(income)
    suspend fun deleteIncome(income: Income) = db.incomeDao().deleteIncome(income)
    suspend fun getCurrentMonthTotalIncome(): Double = db.incomeDao().getCurrentMonthTotalIncome() ?: 0.0
    
    fun getAllExpenses(): Flow<List<Expense>> = db.expenseDao().getAllExpenses()
    fun getUserExpenses(userId: Int): Flow<List<Expense>> = db.expenseDao().getUserExpenses(userId)
    suspend fun insertExpense(expense: Expense): Long = db.expenseDao().insertExpense(expense)
    suspend fun updateExpense(expense: Expense) = db.expenseDao().updateExpense(expense)
    suspend fun deleteExpense(expense: Expense) = db.expenseDao().deleteExpense(expense)
    suspend fun getCurrentMonthTotalExpense(): Double = db.expenseDao().getCurrentMonthTotalExpense() ?: 0.0
    
    fun getActiveEMIs(): Flow<List<EMI>> = db.emiDao().getActiveEMIs()
    fun getUserActiveEMIs(userId: Int): Flow<List<EMI>> = db.emiDao().getUserActiveEMIs(userId)
    suspend fun insertEMI(emi: EMI): Long = db.emiDao().insertEMI(emi)
    suspend fun updateEMI(emi: EMI) = db.emiDao().updateEMI(emi)
    suspend fun deleteEMI(emi: EMI) = db.emiDao().deleteEMI(emi)
    suspend fun getEMIById(emiId: Int): EMI? = db.emiDao().getEMIById(emiId)
    suspend fun makeEMIPayment(emiId: Int, nextDate: Long) = db.emiDao().makeEMIPayment(emiId, nextDate)
    suspend fun completeEMI(emiId: Int) = db.emiDao().completeEMI(emiId)
    suspend fun getCurrentMonthEMICount(): Int = db.emiDao().getCurrentMonthEMICount()
    suspend fun getCurrentMonthEMIAmount(): Double = db.emiDao().getCurrentMonthEMIAmount() ?: 0.0
    
    fun getActiveBorrows(): Flow<List<Borrow>> = db.borrowDao().getActiveBorrows()
    fun getUserActiveBorrows(userId: Int): Flow<List<Borrow>> = db.borrowDao().getUserActiveBorrows(userId)
    suspend fun insertBorrow(borrow: Borrow): Long = db.borrowDao().insertBorrow(borrow)
    suspend fun updateBorrow(borrow: Borrow) = db.borrowDao().updateBorrow(borrow)
    suspend fun deleteBorrow(borrow: Borrow) = db.borrowDao().deleteBorrow(borrow)
    suspend fun getBorrowById(borrowId: Int): Borrow? = db.borrowDao().getBorrowById(borrowId)
    suspend fun markBorrowAsReturned(borrowId: Int, fullAmount: Double, returnDate: Long) = 
        db.borrowDao().markBorrowAsReturned(borrowId, fullAmount, returnDate)
    suspend fun updateBorrowPayment(borrowId: Int, amount: Double) = 
        db.borrowDao().updateBorrowPayment(borrowId, amount)
    suspend fun getTotalPendingBorrowAmount(): Double = db.borrowDao().getTotalPendingBorrowAmount() ?: 0.0
}