package com.example.familyfinancetracker.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface IncomeDao {
    
    @Query("SELECT * FROM incomes ORDER BY date DESC")
    fun getAllIncomes(): Flow<List<Income>>
    
    @Query("SELECT * FROM incomes WHERE userId = :userId ORDER BY date DESC")
    fun getUserIncomes(userId: Int): Flow<List<Income>>
    
    @Insert
    suspend fun insertIncome(income: Income): Long
    
    @Update
    suspend fun updateIncome(income: Income)
    
    @Delete
    suspend fun deleteIncome(income: Income)
    
    @Query("SELECT SUM(amount) FROM incomes WHERE strftime('%m', date/1000, 'unixepoch') = strftime('%m', 'now') AND strftime('%Y', date/1000, 'unixepoch') = strftime('%Y', 'now')")
    suspend fun getCurrentMonthTotalIncome(): Double
    
    @Query("SELECT SUM(amount) FROM incomes WHERE userId = :userId AND strftime('%m', date/1000, 'unixepoch') = strftime('%m', 'now') AND strftime('%Y', date/1000, 'unixepoch') = strftime('%Y', 'now')")
    suspend fun getUserCurrentMonthTotalIncome(userId: Int): Double
}