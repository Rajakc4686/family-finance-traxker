package com.example.familyfinancetracker.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {
    
    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): Flow<List<Expense>>
    
    @Query("SELECT * FROM expenses WHERE userId = :userId ORDER BY date DESC")
    fun getUserExpenses(userId: Int): Flow<List<Expense>>
    
    @Insert
    suspend fun insertExpense(expense: Expense): Long
    
    @Update
    suspend fun updateExpense(expense: Expense)
    
    @Delete
    suspend fun deleteExpense(expense: Expense)
    
    @Query("SELECT SUM(amount) FROM expenses WHERE strftime('%m', date/1000, 'unixepoch') = strftime('%m', 'now') AND strftime('%Y', date/1000, 'unixepoch') = strftime('%Y', 'now')")
    suspend fun getCurrentMonthTotalExpense(): Double
    
    @Query("SELECT SUM(amount) FROM expenses WHERE userId = :userId AND strftime('%m', date/1000, 'unixepoch') = strftime('%m', 'now') AND strftime('%Y', date/1000, 'unixepoch') = strftime('%Y', 'now')")
    suspend fun getUserCurrentMonthTotalExpense(userId: Int): Double
}