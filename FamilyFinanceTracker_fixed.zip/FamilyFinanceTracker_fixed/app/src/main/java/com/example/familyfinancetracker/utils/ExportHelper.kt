package com.example.familyfinancetracker.utils

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.familyfinancetracker.BuildConfig
import com.example.familyfinancetracker.data.Borrow
import com.example.familyfinancetracker.data.EMI
import com.example.familyfinancetracker.data.Expense
import com.example.familyfinancetracker.data.Income
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.*

class ExportHelper(private val context: Context) {
    
    fun exportAllData(
        incomes: List<Income>,
        expenses: List<Expense>,
        emis: List<EMI>,
        borrows: List<Borrow>,
        fileName: String = "finance_report"
    ): File? {
        return try {
            val file = createFile(fileName, "csv")
            val writer = OutputStreamWriter(FileOutputStream(file))
            
            writer.write("FAMILY FINANCE TRACKER - EXPORT REPORT\n")
            writer.write("Generated: ${SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date())}\n\n")
            
            writer.write("SUMMARY\n")
            writer.write("Total Income,${String.format("%.2f", incomes.sumOf { it.amount })}\n")
            writer.write("Total Expense,${String.format("%.2f", expenses.sumOf { it.amount })}\n")
            writer.write("Total EMI,${String.format("%.2f", emis.sumOf { it.monthlyAmount })}\n")
            writer.write("Total Borrow,${String.format("%.2f", borrows.sumOf { it.amount })}\n\n")
            
            writer.write("INCOMES\nSource,Category,Amount,Date,User\n")
            incomes.forEach { writer.write("${it.source},${it.category},${it.amount},${DateUtils.formatDate(it.date)},${it.userName}\n") }
            writer.write("\nEXPENSES\nCategory,Description,Amount,Date,User\n")
            expenses.forEach { writer.write("${it.category},${it.description},${it.amount},${DateUtils.formatDate(it.date)},${it.userName}\n") }
            
            writer.close()
            Toast.makeText(context, "✅ Export successful", Toast.LENGTH_SHORT).show()
            file
        } catch (e: Exception) {
            Toast.makeText(context, "❌ Export failed: ${e.message}", Toast.LENGTH_SHORT).show()
            null
        }
    }
    
    fun shareFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share Report"))
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to share: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun createFile(fileName: String, extension: String): File {
        val folder = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "FamilyFinance")
        if (!folder.exists()) folder.mkdirs()
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return File(folder, "${fileName}_${timestamp}.$extension")
    }
}