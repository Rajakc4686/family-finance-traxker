package com.example.familyfinancetracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "incomes")
data class Income(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val userName: String,
    val source: String,
    val amount: Double,
    val date: Long,
    val category: String,
    val description: String = "",
    val isRecurring: Boolean = false,
    val recurringFrequency: String = "",
    val createdAt: Long = System.currentTimeMillis()
)