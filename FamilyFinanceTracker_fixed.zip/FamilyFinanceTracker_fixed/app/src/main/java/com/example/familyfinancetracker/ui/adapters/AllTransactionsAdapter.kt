package com.example.familyfinancetracker.ui.history

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.familyfinancetracker.R
import com.example.familyfinancetracker.utils.CurrencyUtils
import com.example.familyfinancetracker.utils.DateUtils

class AllTransactionsAdapter(
    private var transactions: List<TransactionItem>,
    private val onItemClick: (TransactionItem) -> Unit
) : RecyclerView.Adapter<AllTransactionsAdapter.TransactionViewHolder>() {

    private var filteredTransactions = transactions

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_all_transaction, parent, false)
        return TransactionViewHolder(view)
    }

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        val transaction = filteredTransactions[position]
        holder.bind(transaction)
        holder.itemView.setOnClickListener { onItemClick(transaction) }
    }

    override fun getItemCount(): Int = filteredTransactions.size

    fun updateData(newList: List<TransactionItem>) {
        transactions = newList
        filteredTransactions = newList
        notifyDataSetChanged()
    }
    
    fun filter(type: String, query: String) {
        filteredTransactions = transactions.filter { transaction ->
            val typeMatch = type == "All" || transaction.getType().contains(type, ignoreCase = true)
            val queryMatch = query.isEmpty() || when (transaction) {
                is TransactionItem.IncomeItem -> 
                    transaction.source.contains(query, ignoreCase = true) ||
                    transaction.category.contains(query, ignoreCase = true)
                is TransactionItem.ExpenseItem ->
                    transaction.description.contains(query, ignoreCase = true) ||
                    transaction.category.contains(query, ignoreCase = true)
                is TransactionItem.EMIItem ->
                    transaction.bankName.contains(query, ignoreCase = true)
                is TransactionItem.BorrowItem ->
                    transaction.personName.contains(query, ignoreCase = true)
            }
            typeMatch && queryMatch
        }
        notifyDataSetChanged()
    }

    inner class TransactionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val cardView: CardView = itemView.findViewById(R.id.cardTransaction)
        private val tvType: TextView = itemView.findViewById(R.id.tvTransactionType)
        private val tvTitle: TextView = itemView.findViewById(R.id.tvTransactionTitle)
        private val tvAmount: TextView = itemView.findViewById(R.id.tvTransactionAmount)
        private val tvDate: TextView = itemView.findViewById(R.id.tvTransactionDate)
        private val tvUser: TextView = itemView.findViewById(R.id.tvTransactionUser)
        private val tvDetails: TextView = itemView.findViewById(R.id.tvTransactionDetails)

        fun bind(transaction: TransactionItem) {
            tvType.text = transaction.getType()
            tvAmount.text = CurrencyUtils.formatCurrencyWithSymbol(transaction.getAmount())
            tvDate.text = DateUtils.formatDate(transaction.getDate())
            tvUser.text = "👤 ${transaction.getUserName()}"
            
            val context = itemView.context
            
            when (transaction) {
                is TransactionItem.IncomeItem -> {
                    tvTitle.text = transaction.source
                    tvDetails.text = "📁 ${transaction.category}"
                    cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.income_bg))
                    tvAmount.setTextColor(ContextCompat.getColor(context, R.color.income_text))
                }
                is TransactionItem.ExpenseItem -> {
                    tvTitle.text = transaction.category
                    tvDetails.text = transaction.description
                    cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.expense_bg))
                    tvAmount.setTextColor(ContextCompat.getColor(context, R.color.expense_text))
                }
                is TransactionItem.EMIItem -> {
                    tvTitle.text = transaction.bankName
                    tvDetails.text = "${transaction.paidMonths}/${transaction.totalMonths} months"
                    cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.emi_bg))
                    tvAmount.setTextColor(ContextCompat.getColor(context, R.color.emi_text))
                }
                is TransactionItem.BorrowItem -> {
                    tvTitle.text = transaction.personName
                    tvDetails.text = if (transaction.isReturned) "✅ Returned" else "⏳ Pending"
                    cardView.setCardBackgroundColor(ContextCompat.getColor(context, R.color.borrow_bg))
                    tvAmount.setTextColor(ContextCompat.getColor(context, R.color.borrow_text))
                }
            }
        }
    }
}