package com.example.familyfinancetracker

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.familyfinancetracker.databinding.ActivityProfileBinding
import com.example.familyfinancetracker.utils.SessionManager

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)

        // Load user data
        binding.tvName.text = sessionManager.getUserName() ?: "User"
        binding.tvEmail.text = sessionManager.getUserEmail() ?: "No email"
        binding.cbAdmin.isChecked = sessionManager.isAdmin()

        binding.btnUpdateProfile.setOnClickListener {
            val name = binding.etName.text.toString().trim()
            if (name.isNotEmpty()) {
                // Update profile logic
                Toast.makeText(this, "Profile updated", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnChangePassword.setOnClickListener {
            // Navigate to change password
            Toast.makeText(this, "Change password", Toast.LENGTH_SHORT).show()
        }

        binding.btnBack.setOnClickListener {
            finish()
        }
    }
}