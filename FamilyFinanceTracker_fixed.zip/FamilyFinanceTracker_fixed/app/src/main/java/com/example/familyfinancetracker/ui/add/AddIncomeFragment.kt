package com.example.familyfinancetracker.ui.add

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.example.familyfinancetracker.databinding.FragmentAddIncomeBinding
import com.example.familyfinancetracker.data.Income
import com.example.familyfinancetracker.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class AddIncomeFragment : Fragment() {

    private var _binding: FragmentAddIncomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddIncomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupSpinner()
        setupAddButton()
    }
    
    private fun setupSpinner() {
        val categories = arrayOf("Salary", "Business", "Investment", "Freelance", "Rental", "Other")
        ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            binding.spinnerIncomeCategory.adapter = this
        }
    }
    
    private fun setupAddButton() {
        binding.btnAddIncome.setOnClickListener {
            val source = binding.etIncomeSource.text.toString().trim()
            val amountStr = binding.etIncomeAmount.text.toString().trim()
            val category = binding.spinnerIncomeCategory.selectedItem.toString()
            
            if (source.isEmpty() || amountStr.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            val amount = amountStr.toDoubleOrNull()
            if (amount == null || amount <= 0) {
                Toast.makeText(requireContext(), "Please enter a valid amount", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            lifecycleScope.launch {
                val currentUser = viewModel.currentUser.value
                if (currentUser != null) {
                    val income = Income(
                        userId = currentUser.id,
                        userName = currentUser.name,
                        source = source,
                        amount = amount,
                        date = System.currentTimeMillis(),
                        category = category
                    )
                    viewModel.addIncome(income)
                    Toast.makeText(requireContext(), "Income added successfully", Toast.LENGTH_SHORT).show()
                    clearFields()
                }
            }
        }
    }
    
    private fun clearFields() {
        binding.etIncomeSource.text.clear()
        binding.etIncomeAmount.text.clear()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}