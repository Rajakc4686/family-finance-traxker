package com.example.familyfinancetracker

import android.app.Application
import androidx.appcompat.AppCompatDelegate
import com.example.familyfinancetracker.data.AppDatabase
import com.example.familyfinancetracker.data.Repository

class FamilyFinanceApplication : Application() {
    
    lateinit var repository: Repository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        
        val database = AppDatabase.getDatabase(this)
        repository = Repository(database)
        
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
    }

    companion object {
        lateinit var instance: FamilyFinanceApplication
            private set
    }
}