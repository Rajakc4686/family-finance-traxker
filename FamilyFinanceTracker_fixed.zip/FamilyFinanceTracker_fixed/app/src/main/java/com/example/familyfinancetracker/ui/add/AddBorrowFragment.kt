package com.example.familyfinancetracker.ui.add

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.example.familyfinancetracker.databinding.FragmentAddBorrowBinding
import com.example.familyfinancetracker.data.Borrow
import com.example.familyfinancetracker.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class AddBorrowFragment : Fragment() {

    private var _binding: FragmentAddBorrowBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddBorrowBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupAddButton()
    }
    
    private fun setupAddButton() {
        binding.btnAddBorrow.setOnClickListener {
            val personName = binding.etBorrowPerson.text.toString().trim()
            val amountStr = binding.etBorrowAmount.text.toString().trim()
            val daysStr = binding.etBorrowDays.text.toString().trim()
            
            if (personName.isEmpty() || amountStr.isEmpty() || daysStr.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            val amount = amountStr.toDoubleOrNull()
            val days = daysStr.toIntOrNull()
            
            if (amount == null || days == null) {
                Toast.makeText(requireContext(), "Please enter valid numbers", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            lifecycleScope.launch {
                val currentUser = viewModel.currentUser.value
                if (currentUser != null) {
                    val borrow = Borrow(
                        userId = currentUser.id,
                        userName = currentUser.name,
                        personName = personName,
                        amount = amount,
                        date = System.currentTimeMillis(),
                        returnDate = System.currentTimeMillis() + (days * 24 * 60 * 60 * 1000L),
                        remainingAmount = amount
                    )
                    viewModel.addBorrow(borrow)
                    Toast.makeText(requireContext(), "Borrow entry added", Toast.LENGTH_SHORT).show()
                    clearFields()
                }
            }
        }
    }
    
    private fun clearFields() {
        binding.etBorrowPerson.text.clear()
        binding.etBorrowAmount.text.clear()
        binding.etBorrowDays.text.clear()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}