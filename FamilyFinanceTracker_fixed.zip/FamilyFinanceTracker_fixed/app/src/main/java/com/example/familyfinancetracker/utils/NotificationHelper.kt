package com.example.familyfinancetracker.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.familyfinancetracker.MainActivity
import com.example.familyfinancetracker.R
import com.example.familyfinancetracker.data.Borrow
import com.example.familyfinancetracker.data.EMI

class NotificationHelper(private val context: Context) {
    
    companion object {
        const val CHANNEL_ID = "family_finance_channel"
        const val CHANNEL_NAME = "Family Finance Tracker"
    }
    
    init {
        createNotificationChannel()
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for EMI reminders and borrow alerts"
                enableVibration(true)
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    
    fun showEMIReminder(emi: EMI) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_emi)
            .setContentTitle("EMI Payment Due")
            .setContentText("${emi.bankName} - ₹${String.format("%.2f", emi.monthlyAmount)} due soon")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("Bank: ${emi.bankName}\nAmount: ₹${String.format("%.2f", emi.monthlyAmount)}\nDue: ${DateUtils.formatDate(emi.nextPaymentDate)}"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()
        
        context.getSystemService(NotificationManager::class.java).notify(1001, notification)
    }
}