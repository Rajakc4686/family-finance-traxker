package com.example.familyfinancetracker.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.familyfinancetracker.R
import com.example.familyfinancetracker.data.User

class PendingUserAdapter(
    private var userList: List<User>,
    private val onApproveClick: (User) -> Unit,
    private val onRejectClick: (User) -> Unit
) : RecyclerView.Adapter<PendingUserAdapter.UserViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pending_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = userList[position]
        holder.bind(user)
        holder.btnApprove.setOnClickListener { onApproveClick(user) }
        holder.btnReject.setOnClickListener { onRejectClick(user) }
    }

    override fun getItemCount(): Int = userList.size

    fun updateData(newList: List<User>) {
        userList = newList
        notifyDataSetChanged()
    }

    inner class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tvPendingUserName)
        private val tvEmail: TextView = itemView.findViewById(R.id.tvPendingUserEmail)
        val btnApprove: Button = itemView.findViewById(R.id.btnApproveUser)
        val btnReject: Button = itemView.findViewById(R.id.btnRejectUser)

        fun bind(user: User) {
            tvName.text = user.name
            tvEmail.text = user.email
        }
    }
}