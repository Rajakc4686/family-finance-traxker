package com.example.familyfinancetracker.utils

import android.content.Context
import android.graphics.Color
import android.os.Environment
import android.widget.Toast
import com.example.familyfinancetracker.data.Expense
import com.example.familyfinancetracker.data.Income
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class PdfExportHelper(private val context: Context) {

    fun exportToPdf(incomes: List<Income>, expenses: List<Expense>, fileName: String = "finance_report"): File? {
        return try {
            val folder = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "FamilyFinance/PDF")
            if (!folder.exists()) folder.mkdirs()

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val file = File(folder, "${fileName}_${timestamp}.pdf")

            // Create PDF using iText or simple text file
            // For now, create a text file with PDF extension
            val outputStream = FileOutputStream(file)
            val writer = java.io.OutputStreamWriter(outputStream)

            writer.write("FAMILY FINANCE TRACKER - REPORT\n")
            writer.write("Generated: ${DateUtils.formatDateTime(System.currentTimeMillis())}\n\n")

            writer.write("INCOMES\n")
            writer.write("----------------------------------------\n")
            incomes.forEach { income ->
                writer.write("${income.source} | ${income.category} | ₹${income.amount} | ${DateUtils.formatDate(income.date)} | ${income.userName}\n")
            }

            writer.write("\nEXPENSES\n")
            writer.write("----------------------------------------\n")
            expenses.forEach { expense ->
                writer.write("${expense.category} | ${expense.description} | ₹${expense.amount} | ${DateUtils.formatDate(expense.date)} | ${expense.userName}\n")
            }

            val totalIncome = incomes.sumOf { it.amount }
            val totalExpense = expenses.sumOf { it.amount }

            writer.write("\nSUMMARY\n")
            writer.write("----------------------------------------\n")
            writer.write("Total Income: ₹${String.format("%.2f", totalIncome)}\n")
            writer.write("Total Expense: ₹${String.format("%.2f", totalExpense)}\n")
            writer.write("Balance: ₹${String.format("%.2f", totalIncome - totalExpense)}\n")

            writer.close()
            outputStream.close()

            Toast.makeText(context, "PDF exported: ${file.name}", Toast.LENGTH_SHORT).show()
            file
        } catch (e: Exception) {
            Toast.makeText(context, "Export failed: ${e.message}", Toast.LENGTH_SHORT).show()
            null
        }
    }
}