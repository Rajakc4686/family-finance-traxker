package com.example.familyfinancetracker.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.familyfinancetracker.data.AppDatabase
import kotlinx.coroutines.launch

data class TransactionHistory(
    val type: String,
    val category: String,
    val description: String,
    val amount: Double,
    val date: String,
    val userName: String
)

class HistoryViewModel : ViewModel() {

    private val _transactions = MutableLiveData<List<TransactionHistory>>(emptyList())
    val transactions: LiveData<List<TransactionHistory>> = _transactions

    private val _filteredTransactions = MutableLiveData<List<TransactionHistory>>(emptyList())
    val filteredTransactions: LiveData<List<TransactionHistory>> = _filteredTransactions

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    fun loadAllTransactions(db: AppDatabase) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val incomes = db.incomeDao().getAllIncomes()
                val expenses = db.expenseDao().getAllExpenses()
                val emis = db.emiDao().getActiveEMIs()
                val borrows = db.borrowDao().getActiveBorrows()

                val allTransactions = mutableListOf<TransactionHistory>()

                incomes.forEach { income ->
                    allTransactions.add(
                        TransactionHistory(
                            type = "Income",
                            category = income.category,
                            description = income.source,
                            amount = income.amount,
                            date = android.text.format.DateFormat.format("dd MMM yyyy", income.date).toString(),
                            userName = income.userName
                        )
                    )
                }

                expenses.forEach { expense ->
                    allTransactions.add(
                        TransactionHistory(
                            type = "Expense",
                            category = expense.category,
                            description = expense.description,
                            amount = expense.amount,
                            date = android.text.format.DateFormat.format("dd MMM yyyy", expense.date).toString(),
                            userName = expense.userName
                        )
                    )
                }

                emis.forEach { emi ->
                    allTransactions.add(
                        TransactionHistory(
                            type = "EMI",
                            category = "EMI",
                            description = emi.bankName,
                            amount = emi.monthlyAmount,
                            date = android.text.format.DateFormat.format("dd MMM yyyy", emi.nextPaymentDate).toString(),
                            userName = emi.userName
                        )
                    )
                }

                borrows.forEach { borrow ->
                    allTransactions.add(
                        TransactionHistory(
                            type = if (borrow.isReturned) "Borrow (Returned)" else "Borrow",
                            category = "Borrow",
                            description = borrow.personName,
                            amount = borrow.amount,
                            date = android.text.format.DateFormat.format("dd MMM yyyy", borrow.date).toString(),
                            userName = borrow.userName
                        )
                    )
                }

                allTransactions.sortByDescending { it.date }
                _transactions.value = allTransactions
                _filteredTransactions.value = allTransactions

            } catch (e: Exception) {
                _error.value = "Error loading transactions: ${e.message}"
            }
            _isLoading.value = false
        }
    }

    fun filterTransactions(query: String, type: String) {
        val all = _transactions.value ?: emptyList()
        _filteredTransactions.value = all.filter { transaction ->
            val typeMatch = type == "All" || transaction.type == type
            val queryMatch = query.isEmpty() ||
                    transaction.category.contains(query, ignoreCase = true) ||
                    transaction.description.contains(query, ignoreCase = true) ||
                    transaction.userName.contains(query, ignoreCase = true)
            typeMatch && queryMatch
        }
    }

    fun clearError() {
        _error.value = null
    }
}