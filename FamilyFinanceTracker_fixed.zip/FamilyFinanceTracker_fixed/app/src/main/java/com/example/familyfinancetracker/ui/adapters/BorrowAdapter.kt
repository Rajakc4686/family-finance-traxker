package com.example.familyfinancetracker.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.familyfinancetracker.R
import com.example.familyfinancetracker.data.Borrow
import com.example.familyfinancetracker.utils.DateUtils
import java.text.SimpleDateFormat
import java.util.*

class BorrowAdapter(
    private var borrowList: List<Borrow>,
    private val onReturnClick: (Borrow) -> Unit,
    private val onEditClick: (Borrow) -> Unit,
    private val onDeleteClick: (Borrow) -> Unit
) : RecyclerView.Adapter<BorrowAdapter.BorrowViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BorrowViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_borrow, parent, false)
        return BorrowViewHolder(view)
    }

    override fun onBindViewHolder(holder: BorrowViewHolder, position: Int) {
        val borrow = borrowList[position]
        holder.bind(borrow)
        
        holder.btnReturn.setOnClickListener { 
            if (!borrow.isReturned) onReturnClick(borrow)
        }
        holder.btnEdit.setOnClickListener { onEditClick(borrow) }
        holder.btnDelete.setOnClickListener { onDeleteClick(borrow) }
    }

    override fun getItemCount(): Int = borrowList.size

    fun updateData(newList: List<Borrow>) {
        borrowList = newList
        notifyDataSetChanged()
    }

    inner class BorrowViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val cardView: CardView = itemView.findViewById(R.id.cardBorrow)
        private val tvPerson: TextView = itemView.findViewById(R.id.tvBorrowPerson)
        private val tvAmount: TextView = itemView.findViewById(R.id.tvBorrowAmount)
        private val tvReturnDate: TextView = itemView.findViewById(R.id.tvBorrowReturnDate)
        private val tvRemaining: TextView = itemView.findViewById(R.id.tvBorrowRemaining)
        private val tvStatus: TextView = itemView.findViewById(R.id.tvBorrowStatus)
        private val tvPurpose: TextView = itemView.findViewById(R.id.tvBorrowPurpose)
        val btnReturn: Button = itemView.findViewById(R.id.btnReturnBorrow)
        val btnEdit: Button = itemView.findViewById(R.id.btnEditBorrow)
        val btnDelete: Button = itemView.findViewById(R.id.btnDeleteBorrow)

        fun bind(borrow: Borrow) {
            tvPerson.text = borrow.personName
            tvAmount.text = "₹${String.format("%.2f", borrow.amount)}"
            tvReturnDate.text = "Return: ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(borrow.returnDate))}"
            
            val remaining = borrow.amount - borrow.returnedAmount
            tvRemaining.text = "Remaining: ₹${String.format("%.2f", remaining)}"
            
            tvStatus.text = if (borrow.isReturned) "✅ Returned" else "🟢 Active"
            tvPurpose.text = if (borrow.purpose.isNotEmpty()) "Purpose: ${borrow.purpose}" else ""
            
            btnReturn.isEnabled = !borrow.isReturned
            btnReturn.text = if (borrow.isReturned) "Returned" else "Mark Returned"
        }
    }
}