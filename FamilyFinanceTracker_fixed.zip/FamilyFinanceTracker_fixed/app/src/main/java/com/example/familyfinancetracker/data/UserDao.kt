package com.example.familyfinancetracker.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    
    @Query("SELECT * FROM users ORDER BY id DESC")
    fun getAllUsers(): Flow<List<User>>
    
    @Query("SELECT * FROM users WHERE email = :email AND password = :password")
    suspend fun login(email: String, password: String): User?
    
    @Query("SELECT * FROM users WHERE email = :email")
    suspend fun getUserByEmail(email: String): User?
    
    @Query("SELECT * FROM users WHERE id = :userId")
    suspend fun getUserById(userId: Int): User?
    
    @Insert
    suspend fun insertUser(user: User): Long
    
    @Update
    suspend fun updateUser(user: User)
    
    @Delete
    suspend fun deleteUser(user: User)
    
    @Query("SELECT * FROM users WHERE isAdmin = 0 AND isApproved = 0")
    fun getPendingApprovals(): Flow<List<User>>
    
    @Query("SELECT * FROM users WHERE isAdmin = 1")
    fun getAdmins(): Flow<List<User>>
    
    @Query("SELECT * FROM users WHERE isApproved = 1")
    fun getApprovedUsers(): Flow<List<User>>
    
    @Query("UPDATE users SET isApproved = 1 WHERE id = :userId")
    suspend fun approveUser(userId: Int)
    
    @Query("UPDATE users SET isApproved = 0 WHERE id = :userId")
    suspend fun rejectUser(userId: Int)
}