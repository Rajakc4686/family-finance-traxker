package com.example.familyfinancetracker.utils

import java.text.NumberFormat
import java.util.*

object CurrencyUtils {
    
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    
    init {
        currencyFormat.maximumFractionDigits = 2
        currencyFormat.minimumFractionDigits = 2
    }

    fun formatCurrency(amount: Double): String {
        return currencyFormat.format(amount)
    }

    fun formatCurrencyWithSymbol(amount: Double): String {
        return "₹${String.format("%.2f", amount)}"
    }

    fun parseCurrency(amount: String): Double? {
        return try {
            amount.replace("₹", "").replace(",", "").trim().toDouble()
        } catch (e: Exception) {
            null
        }
    }
}