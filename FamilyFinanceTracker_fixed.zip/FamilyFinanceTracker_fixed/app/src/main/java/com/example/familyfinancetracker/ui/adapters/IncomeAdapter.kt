package com.example.familyfinancetracker.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.familyfinancetracker.R
import com.example.familyfinancetracker.data.Income
import com.example.familyfinancetracker.utils.CurrencyUtils
import com.example.familyfinancetracker.utils.DateUtils

class IncomeAdapter(
    private var incomeList: List<Income>
) : RecyclerView.Adapter<IncomeAdapter.IncomeViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IncomeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_income, parent, false)
        return IncomeViewHolder(view)
    }

    override fun onBindViewHolder(holder: IncomeViewHolder, position: Int) {
        val income = incomeList[position]
        holder.bind(income)
    }

    override fun getItemCount(): Int = incomeList.size

    fun updateData(newList: List<Income>) {
        incomeList = newList
        notifyDataSetChanged()
    }

    inner class IncomeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivIcon: ImageView = itemView.findViewById(R.id.ivIncomeIcon)
        private val tvSource: TextView = itemView.findViewById(R.id.tvIncomeSource)
        private val tvAmount: TextView = itemView.findViewById(R.id.tvIncomeAmount)
        private val tvCategory: TextView = itemView.findViewById(R.id.tvIncomeCategory)
        private val tvDate: TextView = itemView.findViewById(R.id.tvIncomeDate)
        private val tvUser: TextView = itemView.findViewById(R.id.tvIncomeUser)

        fun bind(income: Income) {
            tvSource.text = income.source
            tvAmount.text = CurrencyUtils.formatCurrencyWithSymbol(income.amount)
            tvCategory.text = income.category
            tvDate.text = DateUtils.formatDate(income.date)
            tvUser.text = "👤 ${income.userName}"
        }
    }
}