package com.example.familyfinancetracker.ui.history

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.familyfinancetracker.R
import com.example.familyfinancetracker.databinding.FragmentHistoryBinding
import com.example.familyfinancetracker.utils.ExportHelper
import com.example.familyfinancetracker.viewmodel.MainViewModel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    
    private lateinit var allTransactionsAdapter: AllTransactionsAdapter
    private var searchQuery = ""
    private var selectedFilter = "All"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupRecyclerView()
        setupFilterButtons()
        loadData()
        setupExportButton()
    }
    
    private fun setupRecyclerView() {
        allTransactionsAdapter = AllTransactionsAdapter(emptyList()) { transaction ->
            showTransactionDetails(transaction)
        }
        
        binding.rvAllTransactions.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = allTransactionsAdapter
        }
    }
    
    private fun setupFilterButtons() {
        binding.chipGroupFilter.setOnCheckedStateChangeListener { _, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                selectedFilter = when (checkedIds[0]) {
                    binding.chipAll.id -> "All"
                    binding.chipIncome.id -> "Income"
                    binding.chipExpense.id -> "Expense"
                    binding.chipEmi.id -> "EMI"
                    binding.chipBorrow.id -> "Borrow"
                    else -> "All"
                }
                applyFilters()
            }
        }
    }
    
    private fun loadData() {
        lifecycleScope.launch {
            combine(
                viewModel.allIncomes,
                viewModel.allExpenses,
                viewModel.activeEMIs,
                viewModel.activeBorrows
            ) { incomes, expenses, emis, borrows ->
                val allTransactions = mutableListOf<TransactionItem>()
                
                incomes.forEach { income ->
                    allTransactions.add(
                        TransactionItem.IncomeItem(
                            id = income.id,
                            source = income.source,
                            amount = income.amount,
                            date = income.date,
                            category = income.category,
                            userName = income.userName
                        )
                    )
                }
                
                expenses.forEach { expense ->
                    allTransactions.add(
                        TransactionItem.ExpenseItem(
                            id = expense.id,
                            category = expense.category,
                            description = expense.description,
                            amount = expense.amount,
                            date = expense.date,
                            userName = expense.userName
                        )
                    )
                }
                
                emis.forEach { emi ->
                    allTransactions.add(
                        TransactionItem.EMIItem(
                            id = emi.id,
                            bankName = emi.bankName,
                            amount = emi.monthlyAmount,
                            date = emi.nextPaymentDate,
                            paidMonths = emi.paidMonths,
                            totalMonths = emi.totalMonths,
                            userName = emi.userName
                        )
                    )
                }
                
                borrows.forEach { borrow ->
                    allTransactions.add(
                        TransactionItem.BorrowItem(
                            id = borrow.id,
                            personName = borrow.personName,
                            amount = borrow.amount,
                            date = borrow.date,
                            returnDate = borrow.returnDate,
                            isReturned = borrow.isReturned,
                            userName = borrow.userName
                        )
                    )
                }
                
                allTransactions.sortByDescending { it.getDate() }
                allTransactions
            }.collect { transactions ->
                allTransactionsAdapter.updateData(transactions)
                applyFilters()
                updateStats(transactions)
            }
        }
    }
    
    private fun applyFilters() {
        allTransactionsAdapter.filter(selectedFilter, searchQuery)
    }
    
    private fun updateStats(transactions: List<TransactionItem>) {
        val totalIncome = transactions.filterIsInstance<TransactionItem.IncomeItem>().sumOf { it.amount }
        val totalExpense = transactions.filterIsInstance<TransactionItem.ExpenseItem>().sumOf { it.amount }
        val totalEMI = transactions.filterIsInstance<TransactionItem.EMIItem>().sumOf { it.amount }
        val totalBorrow = transactions.filterIsInstance<TransactionItem.BorrowItem>().sumOf { it.amount }
        
        binding.apply {
            tvTotalIncome.text = "₹${String.format("%.2f", totalIncome)}"
            tvTotalExpense.text = "₹${String.format("%.2f", totalExpense)}"
            tvTotalEMI.text = "₹${String.format("%.2f", totalEMI)}"
            tvTotalBorrow.text = "₹${String.format("%.2f", totalBorrow)}"
            tvTotalTransactions.text = "${transactions.size} transactions"
        }
    }
    
    private fun setupExportButton() {
        binding.btnExport.setOnClickListener {
            showExportDialog()
        }
    }
    
    private fun showExportDialog() {
        val options = arrayOf("Export CSV", "Export PDF", "Share Report")
        
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Export Report")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> exportCSV()
                    1 -> exportPDF()
                    2 -> shareReport()
                }
            }
            .show()
    }
    
    private fun exportCSV() {
        lifecycleScope.launch {
            val incomes = viewModel.allIncomes.value
            val expenses = viewModel.allExpenses.value
            val emis = viewModel.activeEMIs.value
            val borrows = viewModel.activeBorrows.value
            
            val exportHelper = ExportHelper(requireContext())
            val file = exportHelper.exportAllData(incomes, expenses, emis, borrows)
            if (file != null) {
                exportHelper.shareFile(file)
            }
        }
    }
    
    private fun exportPDF() {
        Toast.makeText(requireContext(), "PDF export coming soon", Toast.LENGTH_SHORT).show()
        exportCSV()
    }
    
    private fun shareReport() {
        exportCSV()
    }
    
    private fun showTransactionDetails(transaction: TransactionItem) {
        val details = when (transaction) {
            is TransactionItem.IncomeItem -> """
                📊 Income Details
                
                Source: ${transaction.source}
                Amount: ₹${String.format("%.2f", transaction.amount)}
                Category: ${transaction.category}
                Date: ${android.text.format.DateFormat.format("dd MMM yyyy HH:mm", transaction.date)}
                Added by: ${transaction.userName}
            """.trimIndent()
            
            is TransactionItem.ExpenseItem -> """
                💸 Expense Details
                
                Category: ${transaction.category}
                Description: ${transaction.description}
                Amount: ₹${String.format("%.2f", transaction.amount)}
                Date: ${android.text.format.DateFormat.format("dd MMM yyyy HH:mm", transaction.date)}
                Added by: ${transaction.userName}
            """.trimIndent()
            
            is TransactionItem.EMIItem -> """
                🏦 EMI Details
                
                Bank: ${transaction.bankName}
                Amount: ₹${String.format("%.2f", transaction.amount)}
                Progress: ${transaction.paidMonths}/${transaction.totalMonths} months
                Next Due: ${android.text.format.DateFormat.format("dd MMM yyyy", transaction.date)}
                Added by: ${transaction.userName}
            """.trimIndent()
            
            is TransactionItem.BorrowItem -> """
                💰 Borrow Details
                
                Person: ${transaction.personName}
                Amount: ₹${String.format("%.2f", transaction.amount)}
                Status: ${if (transaction.isReturned) "✅ Returned" else "⏳ Pending"}
                Return Date: ${android.text.format.DateFormat.format("dd MMM yyyy", transaction.returnDate)}
                Added by: ${transaction.userName}
            """.trimIndent()
        }
        
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Transaction Details")
            .setMessage(details)
            .setPositiveButton("Close", null)
            .show()
    }
    
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.history_menu, menu)
        
        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView
        
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                searchQuery = query ?: ""
                applyFilters()
                return true
            }
            
            override fun onQueryTextChange(newText: String?): Boolean {
                searchQuery = newText ?: ""
                applyFilters()
                return true
            }
        })
        
        super.onCreateOptionsMenu(menu, inflater)
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_filter_date -> {
                Toast.makeText(requireContext(), "Date filter coming soon", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}