package com.example.familyfinancetracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "emis")
data class EMI(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val userName: String,
    val bankName: String,
    val totalAmount: Double,
    val monthlyAmount: Double,
    val totalMonths: Int,
    val paidMonths: Int = 0,
    val startDate: Long,
    val nextPaymentDate: Long,
    val isActive: Boolean = true,
    val loanType: String = "Personal",
    val interestRate: Double = 0.0,
    val processingFee: Double = 0.0,
    val emiDay: Int = 1,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)