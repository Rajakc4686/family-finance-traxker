package com.example.familyfinancetracker.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BorrowDao {
    
    @Query("SELECT * FROM borrows WHERE isReturned = 0 ORDER BY returnDate ASC")
    fun getActiveBorrows(): Flow<List<Borrow>>
    
    @Query("SELECT * FROM borrows WHERE userId = :userId AND isReturned = 0 ORDER BY returnDate ASC")
    fun getUserActiveBorrows(userId: Int): Flow<List<Borrow>>
    
    @Query("SELECT * FROM borrows WHERE isReturned = 1 ORDER BY actualReturnDate DESC")
    fun getReturnedBorrows(): Flow<List<Borrow>>
    
    @Query("SELECT * FROM borrows WHERE id = :borrowId")
    suspend fun getBorrowById(borrowId: Int): Borrow?
    
    @Insert
    suspend fun insertBorrow(borrow: Borrow): Long
    
    @Update
    suspend fun updateBorrow(borrow: Borrow)
    
    @Delete
    suspend fun deleteBorrow(borrow: Borrow)
    
    @Query("UPDATE borrows SET isReturned = 1, returnedAmount = :fullAmount, remainingAmount = 0, actualReturnDate = :returnDate WHERE id = :borrowId")
    suspend fun markBorrowAsReturned(borrowId: Int, fullAmount: Double, returnDate: Long)
    
    @Query("UPDATE borrows SET returnedAmount = returnedAmount + :amount, remainingAmount = remainingAmount - :amount WHERE id = :borrowId")
    suspend fun updateBorrowPayment(borrowId: Int, amount: Double)
    
    @Query("SELECT SUM(amount - returnedAmount) FROM borrows WHERE isReturned = 0")
    suspend fun getTotalPendingBorrowAmount(): Double
}