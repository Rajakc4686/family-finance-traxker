package com.example.familyfinancetracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val userName: String,
    val category: String,
    val description: String,
    val amount: Double,
    val date: Long,
    val billImagePath: String? = null,
    val isRecurring: Boolean = false,
    val recurringFrequency: String = "",
    val paymentMethod: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)