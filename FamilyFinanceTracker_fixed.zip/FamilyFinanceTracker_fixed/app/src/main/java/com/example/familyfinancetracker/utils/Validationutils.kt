package com.example.familyfinancetracker.utils

import android.widget.EditText
import java.util.regex.Pattern

object ValidationUtils {

    private val EMAIL_PATTERN = Pattern.compile(
        "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
                "\\@" +
                "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
                "(" +
                "\\." +
                "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
                ")+"
    )

    private val PHONE_PATTERN = Pattern.compile("^[6-9]\\d{9}$")

    fun isValidEmail(email: String): Boolean {
        return EMAIL_PATTERN.matcher(email).matches()
    }

    fun isValidPhone(phone: String): Boolean {
        return PHONE_PATTERN.matcher(phone).matches()
    }

    fun isValidAmount(amount: String): Boolean {
        return try {
            val value = amount.toDouble()
            value > 0
        } catch (e: NumberFormatException) {
            false
        }
    }

    fun isValidPassword(password: String): Boolean {
        return password.length >= 6 &&
                password.any { it.isUpperCase() } &&
                password.any { it.isLowerCase() } &&
                password.any { it.isDigit() }
    }

    fun validateEditTexts(vararg editTexts: EditText): Boolean {
        var isValid = true
        editTexts.forEach { editText ->
            if (editText.text.toString().trim().isEmpty()) {
                editText.error = "This field is required"
                isValid = false
            }
        }
        return isValid
    }

    fun validateEditTextsWithCustom(vararg pairs: Pair<EditText, String>): Boolean {
        var isValid = true
        pairs.forEach { (editText, errorMessage) ->
            if (editText.text.toString().trim().isEmpty()) {
                editText.error = errorMessage
                isValid = false
            }
        }
        return isValid
    }

    fun isNullOrEmpty(str: String?): Boolean {
        return str == null || str.trim().isEmpty()
    }
}