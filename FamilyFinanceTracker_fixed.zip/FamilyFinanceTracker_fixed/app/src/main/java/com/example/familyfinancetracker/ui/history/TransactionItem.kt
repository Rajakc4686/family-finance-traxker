package com.example.familyfinancetracker.ui.history

sealed class TransactionItem {
    abstract fun getDate(): Long
    abstract fun getType(): String
    abstract fun getAmount(): Double
    abstract fun getUserName(): String
    
    data class IncomeItem(
        val id: Int,
        val source: String,
        val amount: Double,
        val date: Long,
        val category: String,
        val userName: String
    ) : TransactionItem() {
        override fun getDate(): Long = date
        override fun getType(): String = "Income"
        override fun getAmount(): Double = amount
        override fun getUserName(): String = userName
    }
    
    data class ExpenseItem(
        val id: Int,
        val category: String,
        val description: String,
        val amount: Double,
        val date: Long,
        val userName: String
    ) : TransactionItem() {
        override fun getDate(): Long = date
        override fun getType(): String = "Expense"
        override fun getAmount(): Double = amount
        override fun getUserName(): String = userName
    }
    
    data class EMIItem(
        val id: Int,
        val bankName: String,
        val amount: Double,
        val date: Long,
        val paidMonths: Int,
        val totalMonths: Int,
        val userName: String
    ) : TransactionItem() {
        override fun getDate(): Long = date
        override fun getType(): String = "EMI"
        override fun getAmount(): Double = amount
        override fun getUserName(): String = userName
    }
    
    data class BorrowItem(
        val id: Int,
        val personName: String,
        val amount: Double,
        val date: Long,
        val returnDate: Long,
        val isReturned: Boolean,
        val userName: String
    ) : TransactionItem() {
        override fun getDate(): Long = date
        override fun getType(): String = if (isReturned) "Borrow (Returned)" else "Borrow"
        override fun getAmount(): Double = amount
        override fun getUserName(): String = userName
    }
}