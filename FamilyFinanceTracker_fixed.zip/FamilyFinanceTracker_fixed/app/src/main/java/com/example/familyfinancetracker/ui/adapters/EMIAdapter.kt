package com.example.familyfinancetracker.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.familyfinancetracker.R
import com.example.familyfinancetracker.data.EMI
import com.example.familyfinancetracker.utils.DateUtils
import java.text.SimpleDateFormat
import java.util.*

class EMIAdapter(
    private var emiList: List<EMI>,
    private val onPaymentClick: (EMI) -> Unit,
    private val onEditClick: (EMI) -> Unit,
    private val onDeleteClick: (EMI) -> Unit
) : RecyclerView.Adapter<EMIAdapter.EMIViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EMIViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_emi, parent, false)
        return EMIViewHolder(view)
    }

    override fun onBindViewHolder(holder: EMIViewHolder, position: Int) {
        val emi = emiList[position]
        holder.bind(emi)
        
        holder.btnPay.setOnClickListener { onPaymentClick(emi) }
        holder.btnEdit.setOnClickListener { onEditClick(emi) }
        holder.btnDelete.setOnClickListener { onDeleteClick(emi) }
    }

    override fun getItemCount(): Int = emiList.size

    fun updateData(newList: List<EMI>) {
        emiList = newList
        notifyDataSetChanged()
    }

    inner class EMIViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val cardView: CardView = itemView.findViewById(R.id.cardEmi)
        private val tvBankName: TextView = itemView.findViewById(R.id.tvEmiBankName)
        private val tvAmount: TextView = itemView.findViewById(R.id.tvEmiAmount)
        private val tvNextDate: TextView = itemView.findViewById(R.id.tvEmiNextDate)
        private val tvPaidMonths: TextView = itemView.findViewById(R.id.tvEmiPaidMonths)
        private val tvRemaining: TextView = itemView.findViewById(R.id.tvEmiRemaining)
        private val progressBar: ProgressBar = itemView.findViewById(R.id.progressEmi)
        private val tvStatus: TextView = itemView.findViewById(R.id.tvEmiStatus)
        val btnPay: Button = itemView.findViewById(R.id.btnPayEmi)
        val btnEdit: Button = itemView.findViewById(R.id.btnEditEmi)
        val btnDelete: Button = itemView.findViewById(R.id.btnDeleteEmi)

        fun bind(emi: EMI) {
            tvBankName.text = emi.bankName
            tvAmount.text = "₹${String.format("%.2f", emi.monthlyAmount)}"
            tvNextDate.text = "Next: ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(emi.nextPaymentDate))}"
            
            val remainingMonths = emi.totalMonths - emi.paidMonths
            val remainingAmount = remainingMonths * emi.monthlyAmount
            tvPaidMonths.text = "${emi.paidMonths}/${emi.totalMonths} months"
            tvRemaining.text = "Remaining: ₹${String.format("%.2f", remainingAmount)}"
            
            val progress = if (emi.totalMonths > 0) (emi.paidMonths.toFloat() / emi.totalMonths) * 100 else 0f
            progressBar.progress = progress.toInt()
            
            tvStatus.text = if (remainingMonths <= 0) "✅ Completed" else "🟢 Active"
            btnPay.isEnabled = remainingMonths > 0
            btnPay.text = if (remainingMonths <= 0) "Paid" else "Pay EMI"
        }
    }
}