package com.example.familyfinancetracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val email: String,
    val password: String,
    val name: String,
    val isAdmin: Boolean = false,
    val isApproved: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)