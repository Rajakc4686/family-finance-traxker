package com.example.familyfinancetracker.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.familyfinancetracker.databinding.FragmentDashboardBinding
import com.example.familyfinancetracker.ui.adapters.EMIAdapter
import com.example.familyfinancetracker.ui.adapters.ExpenseAdapter
import com.example.familyfinancetracker.utils.CurrencyUtils
import com.example.familyfinancetracker.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    
    private lateinit var emiAdapter: EMIAdapter
    private lateinit var expenseAdapter: ExpenseAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupRecyclerViews()
        observeDashboardData()
        observeEMIs()
        observeExpenses()
    }
    
    private fun setupRecyclerViews() {
        emiAdapter = EMIAdapter(
            emptyList(),
            onPaymentClick = { emi ->
                viewModel.makeEMIPayment(emi.id)
            },
            onEditClick = { /* Edit */ },
            onDeleteClick = { viewModel.deleteEMI(it) }
        )
        
        expenseAdapter = ExpenseAdapter(emptyList())
        
        binding.rvActiveEMIs.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = emiAdapter
        }
        
        binding.rvRecentExpenses.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = expenseAdapter
        }
    }
    
    private fun observeDashboardData() {
        lifecycleScope.launch {
            viewModel.dashboardData.collect { data ->
                binding.apply {
                    tvTotalIncome.text = CurrencyUtils.formatCurrencyWithSymbol(data.totalIncome)
                    tvTotalExpense.text = CurrencyUtils.formatCurrencyWithSymbol(data.totalExpense)
                    tvBalance.text = CurrencyUtils.formatCurrencyWithSymbol(data.totalIncome - data.totalExpense)
                    tvEmiCount.text = "${data.emiCount} EMIs"
                    tvEmiAmount.text = CurrencyUtils.formatCurrencyWithSymbol(data.emiAmount)
                    tvPendingBorrow.text = CurrencyUtils.formatCurrencyWithSymbol(data.pendingBorrow)
                    tvTotalEMIRemaining.text = CurrencyUtils.formatCurrencyWithSymbol(data.totalEMIRemaining)
                }
            }
        }
    }
    
    private fun observeEMIs() {
        lifecycleScope.launch {
            viewModel.activeEMIs.collect { emis ->
                emiAdapter.updateData(emis)
            }
        }
    }
    
    private fun observeExpenses() {
        lifecycleScope.launch {
            viewModel.allExpenses.collect { expenses ->
                expenseAdapter.updateData(expenses.take(5))
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}