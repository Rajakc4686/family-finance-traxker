package com.example.familyfinancetracker.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.familyfinancetracker.data.AppDatabase
import com.example.familyfinancetracker.data.User
import com.example.familyfinancetracker.utils.PasswordUtils
import kotlinx.coroutines.launch

class LoginViewModel : ViewModel() {

    private val _loginResult = MutableLiveData<User?>()
    val loginResult: LiveData<User?> = _loginResult

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    fun login(email: String, password: String, db: AppDatabase) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val hashedPassword = PasswordUtils.hashPassword(password)
                val user = db.userDao().login(email, hashedPassword)
                if (user != null && user.isApproved) {
                    _loginResult.value = user
                    _error.value = null
                } else {
                    _error.value = if (user == null) "Invalid credentials" else "Account not approved"
                    _loginResult.value = null
                }
            } catch (e: Exception) {
                _error.value = "Login error: ${e.message}"
                _loginResult.value = null
            }
            _isLoading.value = false
        }
    }

    fun registerUser(email: String, password: String, name: String, isAdmin: Boolean, db: AppDatabase) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val existingUser = db.userDao().getUserByEmail(email)
                if (existingUser != null) {
                    _error.value = "Email already registered"
                    _loginResult.value = null
                    _isLoading.value = false
                    return@launch
                }
                val hashedPassword = PasswordUtils.hashPassword(password)
                val user = User(
                    email = email,
                    password = hashedPassword,
                    name = name,
                    isAdmin = isAdmin,
                    isApproved = isAdmin
                )
                db.userDao().insertUser(user)
                _loginResult.value = user
                _error.value = null
            } catch (e: Exception) {
                _error.value = "Registration error: ${e.message}"
                _loginResult.value = null
            }
            _isLoading.value = false
        }
    }

    fun clearError() {
        _error.value = null
    }
}