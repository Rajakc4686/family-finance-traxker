package com.example.familyfinancetracker.data

import android.content.Context
import android.os.Environment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

class BackupRepository(private val context: Context) {

    private val gson = Gson()
    private val backupFolder: File by lazy {
        val folder = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            "FamilyFinance/Backup"
        )
        if (!folder.exists()) folder.mkdirs()
        folder
    }

    data class BackupData(
        val users: List<User>,
        val incomes: List<Income>,
        val expenses: List<Expense>,
        val emis: List<EMI>,
        val borrows: List<Borrow>,
        val backupDate: String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
    )

    suspend fun createBackup(db: AppDatabase): File? {
        return try {
            val users = db.userDao().getAllUsers().first()
            val incomes = db.incomeDao().getAllIncomes().first()
            val expenses = db.expenseDao().getAllExpenses().first()
            val emis = db.emiDao().getActiveEMIs().first()
            val borrows = db.borrowDao().getActiveBorrows().first()

            val backupData = BackupData(users, incomes, expenses, emis, borrows)
            val json = gson.toJson(backupData)

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val backupFile = File(backupFolder, "backup_$timestamp.json")
            FileWriter(backupFile).use { it.write(json) }

            backupFile
        } catch (e: Exception) {
            null
        }
    }

    suspend fun restoreBackup(db: AppDatabase, file: File): Boolean {
        return try {
            val json = FileReader(file).readText()
            val backupData: BackupData = gson.fromJson(json, object : TypeToken<BackupData>() {}.type)

            // Clear existing data
            db.userDao().deleteUser(db.userDao().getAllUsers().first())

            // Restore data
            backupData.users.forEach { db.userDao().insertUser(it) }
            backupData.incomes.forEach { db.incomeDao().insertIncome(it) }
            backupData.expenses.forEach { db.expenseDao().insertExpense(it) }
            backupData.emis.forEach { db.emiDao().insertEMI(it) }
            backupData.borrows.forEach { db.borrowDao().insertBorrow(it) }

            true
        } catch (e: Exception) {
            false
        }
    }

    fun getBackupFiles(): List<File> {
        return backupFolder.listFiles()?.filter { it.extension == "json" } ?: emptyList()
    }

    fun deleteBackupFile(file: File): Boolean {
        return try {
            file.delete()
        } catch (e: Exception) {
            false
        }
    }
}