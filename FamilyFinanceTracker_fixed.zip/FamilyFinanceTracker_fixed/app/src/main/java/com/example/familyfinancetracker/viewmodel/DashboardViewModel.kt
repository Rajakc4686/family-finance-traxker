package com.example.familyfinancetracker.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.familyfinancetracker.data.AppDatabase
import com.example.familyfinancetracker.data.EMI
import com.example.familyfinancetracker.data.Expense
import com.example.familyfinancetracker.data.Income
import kotlinx.coroutines.launch

data class DashboardSummary(
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val emiCount: Int = 0,
    val emiAmount: Double = 0.0,
    val pendingBorrow: Double = 0.0,
    val balance: Double = 0.0
)

class DashboardViewModel : ViewModel() {

    private val _summary = MutableLiveData(DashboardSummary())
    val summary: LiveData<DashboardSummary> = _summary

    private val _incomes = MutableLiveData<List<Income>>(emptyList())
    val incomes: LiveData<List<Income>> = _incomes

    private val _expenses = MutableLiveData<List<Expense>>(emptyList())
    val expenses: LiveData<List<Expense>> = _expenses

    private val _emis = MutableLiveData<List<EMI>>(emptyList())
    val emis: LiveData<List<EMI>> = _emis

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    fun loadDashboardData(db: AppDatabase, userId: Int) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val incomes = db.incomeDao().getUserIncomes(userId)
                val expenses = db.expenseDao().getUserExpenses(userId)
                val emis = db.emiDao().getUserActiveEMIs(userId)

                val totalIncome = db.incomeDao().getCurrentMonthTotalIncome() ?: 0.0
                val totalExpense = db.expenseDao().getCurrentMonthTotalExpense() ?: 0.0
                val emiCount = db.emiDao().getCurrentMonthEMICount()
                val emiAmount = db.emiDao().getCurrentMonthEMIAmount() ?: 0.0
                val pendingBorrow = db.borrowDao().getTotalPendingBorrowAmount() ?: 0.0

                _summary.value = DashboardSummary(
                    totalIncome = totalIncome,
                    totalExpense = totalExpense,
                    emiCount = emiCount,
                    emiAmount = emiAmount,
                    pendingBorrow = pendingBorrow,
                    balance = totalIncome - totalExpense
                )

                _incomes.value = incomes
                _expenses.value = expenses
                _emis.value = emis

            } catch (e: Exception) {
                // Handle error
            }
            _isLoading.value = false
        }
    }
}