package com.example.familyfinancetracker.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.familyfinancetracker.R
import com.example.familyfinancetracker.data.Expense
import com.example.familyfinancetracker.utils.CurrencyUtils
import com.example.familyfinancetracker.utils.DateUtils

class ExpenseAdapter(
    private var expenseList: List<Expense>
) : RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_expense, parent, false)
        return ExpenseViewHolder(view)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        val expense = expenseList[position]
        holder.bind(expense)
    }

    override fun getItemCount(): Int = expenseList.size

    fun updateData(newList: List<Expense>) {
        expenseList = newList
        notifyDataSetChanged()
    }

    inner class ExpenseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivIcon: ImageView = itemView.findViewById(R.id.ivExpenseIcon)
        private val tvCategory: TextView = itemView.findViewById(R.id.tvExpenseCategory)
        private val tvDescription: TextView = itemView.findViewById(R.id.tvExpenseDescription)
        private val tvAmount: TextView = itemView.findViewById(R.id.tvExpenseAmount)
        private val tvDate: TextView = itemView.findViewById(R.id.tvExpenseDate)
        private val tvUser: TextView = itemView.findViewById(R.id.tvExpenseUser)

        fun bind(expense: Expense) {
            tvCategory.text = expense.category
            tvDescription.text = expense.description
            tvAmount.text = CurrencyUtils.formatCurrencyWithSymbol(expense.amount)
            tvDate.text = DateUtils.formatDate(expense.date)
            tvUser.text = "👤 ${expense.userName}"
        }
    }
}