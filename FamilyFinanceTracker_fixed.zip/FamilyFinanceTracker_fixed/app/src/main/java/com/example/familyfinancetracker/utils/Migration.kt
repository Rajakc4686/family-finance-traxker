package com.example.familyfinancetracker.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

object Migrations {

    val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(database: SupportSQLiteDatabase) {
            // Add new columns for version 2
            database.execSQL("ALTER TABLE users ADD COLUMN createdAt INTEGER DEFAULT 0")
            database.execSQL("ALTER TABLE incomes ADD COLUMN description TEXT DEFAULT ''")
            database.execSQL("ALTER TABLE incomes ADD COLUMN isRecurring INTEGER DEFAULT 0")
            database.execSQL("ALTER TABLE incomes ADD COLUMN recurringFrequency TEXT DEFAULT ''")
            database.execSQL("ALTER TABLE incomes ADD COLUMN createdAt INTEGER DEFAULT 0")
            database.execSQL("ALTER TABLE expenses ADD COLUMN isRecurring INTEGER DEFAULT 0")
            database.execSQL("ALTER TABLE expenses ADD COLUMN recurringFrequency TEXT DEFAULT ''")
            database.execSQL("ALTER TABLE expenses ADD COLUMN paymentMethod TEXT DEFAULT ''")
            database.execSQL("ALTER TABLE expenses ADD COLUMN notes TEXT DEFAULT ''")
            database.execSQL("ALTER TABLE expenses ADD COLUMN createdAt INTEGER DEFAULT 0")
            database.execSQL("ALTER TABLE emis ADD COLUMN loanType TEXT DEFAULT 'Personal'")
            database.execSQL("ALTER TABLE emis ADD COLUMN interestRate REAL DEFAULT 0.0")
            database.execSQL("ALTER TABLE emis ADD COLUMN processingFee REAL DEFAULT 0.0")
            database.execSQL("ALTER TABLE emis ADD COLUMN emiDay INTEGER DEFAULT 1")
            database.execSQL("ALTER TABLE emis ADD COLUMN notes TEXT DEFAULT ''")
            database.execSQL("ALTER TABLE emis ADD COLUMN createdAt INTEGER DEFAULT 0")
            database.execSQL("ALTER TABLE borrows ADD COLUMN interestRate REAL DEFAULT 0.0")
            database.execSQL("ALTER TABLE borrows ADD COLUMN interestAmount REAL DEFAULT 0.0")
            database.execSQL("ALTER TABLE borrows ADD COLUMN totalWithInterest REAL DEFAULT 0.0")
            database.execSQL("ALTER TABLE borrows ADD COLUMN purpose TEXT DEFAULT ''")
            database.execSQL("ALTER TABLE borrows ADD COLUMN notes TEXT DEFAULT ''")
            database.execSQL("ALTER TABLE borrows ADD COLUMN actualReturnDate INTEGER DEFAULT 0")
            database.execSQL("ALTER TABLE borrows ADD COLUMN createdAt INTEGER DEFAULT 0")
        }
    }

    val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(database: SupportSQLiteDatabase) {
            // Add new tables or columns for version 3
            database.execSQL("CREATE INDEX IF NOT EXISTS idx_incomes_user_id ON incomes(userId)")
            database.execSQL("CREATE INDEX IF NOT EXISTS idx_expenses_user_id ON expenses(userId)")
            database.execSQL("CREATE INDEX IF NOT EXISTS idx_emis_user_id ON emis(userId)")
            database.execSQL("CREATE INDEX IF NOT EXISTS idx_borrows_user_id ON borrows(userId)")
        }
    }
}