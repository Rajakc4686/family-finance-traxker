package com.example.familyfinancetracker.ui.admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.familyfinancetracker.databinding.FragmentAdminBinding
import com.example.familyfinancetracker.ui.adapters.PendingUserAdapter
import com.example.familyfinancetracker.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class AdminFragment : Fragment() {

    private var _binding: FragmentAdminBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    
    private lateinit var pendingUserAdapter: PendingUserAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAdminBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        val currentUser = viewModel.currentUser.value
        if (currentUser?.isAdmin == true) {
            binding.adminLayout.visibility = View.VISIBLE
            binding.tvMessage.visibility = View.GONE
            setupRecyclerView()
            loadPendingApprovals()
            setupRefreshButton()
        } else {
            binding.adminLayout.visibility = View.GONE
            binding.tvMessage.visibility = View.VISIBLE
            binding.tvMessage.text = "⚠️ Only Admin can access this section"
        }
    }
    
    private fun setupRecyclerView() {
        pendingUserAdapter = PendingUserAdapter(emptyList(),
            onApproveClick = { user ->
                lifecycleScope.launch {
                    viewModel.approveUser(user.id)
                    Toast.makeText(requireContext(), "${user.name} approved", Toast.LENGTH_SHORT).show()
                    loadPendingApprovals()
                }
            },
            onRejectClick = { user ->
                Toast.makeText(requireContext(), "Rejected ${user.name}", Toast.LENGTH_SHORT).show()
            }
        )
        
        binding.rvPendingApprovals.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = pendingUserAdapter
        }
    }
    
    private fun loadPendingApprovals() {
        lifecycleScope.launch {
            viewModel.pendingApprovals.collect { users ->
                pendingUserAdapter.updateData(users)
                if (users.isEmpty()) {
                    binding.tvMessage.visibility = View.VISIBLE
                    binding.tvMessage.text = "No pending approvals"
                } else {
                    binding.tvMessage.visibility = View.GONE
                }
            }
        }
    }
    
    private fun setupRefreshButton() {
        binding.btnRefresh.setOnClickListener {
            loadPendingApprovals()
            Toast.makeText(requireContext(), "Refreshed", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}