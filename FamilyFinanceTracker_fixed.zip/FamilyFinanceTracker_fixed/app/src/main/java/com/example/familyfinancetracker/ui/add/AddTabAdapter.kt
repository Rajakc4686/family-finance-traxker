package com.example.familyfinancetracker.ui.add

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter

class AddTabAdapter(fragment: Fragment) : FragmentStateAdapter(fragment) {
    
    override fun getItemCount(): Int = 4
    
    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> AddIncomeFragment()
            1 -> AddExpenseFragment()
            2 -> AddEMIFragment()
            3 -> AddBorrowFragment()
            else -> AddIncomeFragment()
        }
    }
}