package com.example.familyfinancetracker.utils

import java.text.SimpleDateFormat
import java.util.*

object DateUtils {
    
    private val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val dateTimeFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

    fun formatDate(timestamp: Long): String {
        return dateFormat.format(Date(timestamp))
    }

    fun formatDateTime(timestamp: Long): String {
        return dateTimeFormat.format(Date(timestamp))
    }

    fun getDaysDifference(fromDate: Long, toDate: Long): Long {
        val diff = toDate - fromDate
        return diff / (24 * 60 * 60 * 1000)
    }

    fun isDatePassed(timestamp: Long): Boolean {
        return System.currentTimeMillis() > timestamp
    }

    fun addDays(date: Long, days: Int): Long {
        return date + (days * 24 * 60 * 60 * 1000L)
    }
}