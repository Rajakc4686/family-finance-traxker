package com.example.familyfinancetracker.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EMIDao {
    
    @Query("SELECT * FROM emis WHERE isActive = 1 ORDER BY nextPaymentDate ASC")
    fun getActiveEMIs(): Flow<List<EMI>>
    
    @Query("SELECT * FROM emis WHERE userId = :userId AND isActive = 1 ORDER BY nextPaymentDate ASC")
    fun getUserActiveEMIs(userId: Int): Flow<List<EMI>>
    
    @Query("SELECT * FROM emis WHERE isActive = 0 ORDER BY startDate DESC")
    fun getCompletedEMIs(): Flow<List<EMI>>
    
    @Query("SELECT * FROM emis WHERE id = :emiId")
    suspend fun getEMIById(emiId: Int): EMI?
    
    @Insert
    suspend fun insertEMI(emi: EMI): Long
    
    @Update
    suspend fun updateEMI(emi: EMI)
    
    @Delete
    suspend fun deleteEMI(emi: EMI)
    
    @Query("UPDATE emis SET paidMonths = paidMonths + 1, nextPaymentDate = :nextDate WHERE id = :emiId")
    suspend fun makeEMIPayment(emiId: Int, nextDate: Long)
    
    @Query("UPDATE emis SET isActive = 0 WHERE id = :emiId")
    suspend fun completeEMI(emiId: Int)
    
    @Query("SELECT COUNT(*) FROM emis WHERE isActive = 1 AND strftime('%m', nextPaymentDate/1000, 'unixepoch') = strftime('%m', 'now') AND strftime('%Y', nextPaymentDate/1000, 'unixepoch') = strftime('%Y', 'now')")
    suspend fun getCurrentMonthEMICount(): Int
    
    @Query("SELECT SUM(monthlyAmount) FROM emis WHERE isActive = 1 AND strftime('%m', nextPaymentDate/1000, 'unixepoch') = strftime('%m', 'now') AND strftime('%Y', nextPaymentDate/1000, 'unixepoch') = strftime('%Y', 'now')")
    suspend fun getCurrentMonthEMIAmount(): Double
}