package com.example.familyfinancetracker.ui.add

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.familyfinancetracker.databinding.FragmentAddExpenseBinding
import com.example.familyfinancetracker.data.Expense
import com.example.familyfinancetracker.viewmodel.MainViewModel
import com.github.dhaval2404.imagepicker.ImagePicker
import kotlinx.coroutines.launch

class AddExpenseFragment : Fragment() {

    private var _binding: FragmentAddExpenseBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private var billImageUri: Uri? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddExpenseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupSpinner()
        setupAddButton()
        setupBillCapture()
    }
    
    private fun setupSpinner() {
        val categories = arrayOf(
            "Grocery", "Electricity", "Water", "Mobile", "WiFi", 
            "OTT", "School", "Van", "Insurance", "Rent", 
            "Medical", "Entertainment", "Shopping", "Petrol", "Other"
        )
        ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            binding.spinnerExpenseCategory.adapter = this
        }
    }
    
    private fun setupAddButton() {
        binding.btnAddExpense.setOnClickListener {
            val category = binding.spinnerExpenseCategory.selectedItem.toString()
            val description = binding.etExpenseDescription.text.toString().trim()
            val amountStr = binding.etExpenseAmount.text.toString().trim()
            
            if (description.isEmpty() || amountStr.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            val amount = amountStr.toDoubleOrNull()
            if (amount == null || amount <= 0) {
                Toast.makeText(requireContext(), "Please enter a valid amount", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            lifecycleScope.launch {
                val currentUser = viewModel.currentUser.value
                if (currentUser != null) {
                    val expense = Expense(
                        userId = currentUser.id,
                        userName = currentUser.name,
                        category = category,
                        description = description,
                        amount = amount,
                        date = System.currentTimeMillis(),
                        billImagePath = billImageUri?.toString()
                    )
                    viewModel.addExpense(expense)
                    Toast.makeText(requireContext(), "Expense added successfully", Toast.LENGTH_SHORT).show()
                    clearFields()
                }
            }
        }
    }
    
    private fun setupBillCapture() {
        binding.btnCaptureBill.setOnClickListener {
            ImagePicker.with(this)
                .crop()
                .compress(1024)
                .maxResultSize(1080, 1080)
                .start()
        }
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (resultCode == Activity.RESULT_OK && data != null) {
            billImageUri = data.data
            if (billImageUri != null) {
                binding.ivBillPreview.visibility = View.VISIBLE
                Glide.with(this)
                    .load(billImageUri)
                    .centerCrop()
                    .into(binding.ivBillPreview)
            }
        }
    }
    
    private fun clearFields() {
        binding.etExpenseDescription.text.clear()
        binding.etExpenseAmount.text.clear()
        billImageUri = null
        binding.ivBillPreview.visibility = View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}