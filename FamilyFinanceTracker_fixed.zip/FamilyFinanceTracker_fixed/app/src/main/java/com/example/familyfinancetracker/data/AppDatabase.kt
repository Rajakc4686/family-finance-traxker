package com.example.familyfinancetracker.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [User::class, Income::class, Expense::class, EMI::class, Borrow::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    
    abstract fun userDao(): UserDao
    abstract fun incomeDao(): IncomeDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun emiDao(): EMIDao
    abstract fun borrowDao(): BorrowDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE users ADD COLUMN createdAt INTEGER DEFAULT 0")
                database.execSQL("ALTER TABLE incomes ADD COLUMN description TEXT DEFAULT ''")
                database.execSQL("ALTER TABLE incomes ADD COLUMN isRecurring INTEGER DEFAULT 0")
                database.execSQL("ALTER TABLE incomes ADD COLUMN recurringFrequency TEXT DEFAULT ''")
                database.execSQL("ALTER TABLE incomes ADD COLUMN createdAt INTEGER DEFAULT 0")
                database.execSQL("ALTER TABLE expenses ADD COLUMN isRecurring INTEGER DEFAULT 0")
                database.execSQL("ALTER TABLE expenses ADD COLUMN recurringFrequency TEXT DEFAULT ''")
                database.execSQL("ALTER TABLE expenses ADD COLUMN paymentMethod TEXT DEFAULT ''")
                database.execSQL("ALTER TABLE expenses ADD COLUMN notes TEXT DEFAULT ''")
                database.execSQL("ALTER TABLE expenses ADD COLUMN createdAt INTEGER DEFAULT 0")
                database.execSQL("ALTER TABLE emis ADD COLUMN loanType TEXT DEFAULT 'Personal'")
                database.execSQL("ALTER TABLE emis ADD COLUMN interestRate REAL DEFAULT 0.0")
                database.execSQL("ALTER TABLE emis ADD COLUMN processingFee REAL DEFAULT 0.0")
                database.execSQL("ALTER TABLE emis ADD COLUMN emiDay INTEGER DEFAULT 1")
                database.execSQL("ALTER TABLE emis ADD COLUMN notes TEXT DEFAULT ''")
                database.execSQL("ALTER TABLE emis ADD COLUMN createdAt INTEGER DEFAULT 0")
                database.execSQL("ALTER TABLE borrows ADD COLUMN interestRate REAL DEFAULT 0.0")
                database.execSQL("ALTER TABLE borrows ADD COLUMN interestAmount REAL DEFAULT 0.0")
                database.execSQL("ALTER TABLE borrows ADD COLUMN totalWithInterest REAL DEFAULT 0.0")
                database.execSQL("ALTER TABLE borrows ADD COLUMN purpose TEXT DEFAULT ''")
                database.execSQL("ALTER TABLE borrows ADD COLUMN notes TEXT DEFAULT ''")
                database.execSQL("ALTER TABLE borrows ADD COLUMN actualReturnDate INTEGER DEFAULT 0")
                database.execSQL("ALTER TABLE borrows ADD COLUMN createdAt INTEGER DEFAULT 0")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "family_finance_db"
                )
                .addMigrations(MIGRATION_1_2)
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}