package com.example.familyfinancetracker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.familyfinancetracker.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    
    private val db = AppDatabase.getDatabase(application)
    
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()
    
    val allUsers = db.userDao().getAllUsers()
    val allIncomes = db.incomeDao().getAllIncomes()
    val allExpenses = db.expenseDao().getAllExpenses()
    val activeEMIs = db.emiDao().getActiveEMIs()
    val activeBorrows = db.borrowDao().getActiveBorrows()
    val pendingApprovals = db.userDao().getPendingApprovals()
    
    private val _dashboardData = MutableStateFlow(DashboardData())
    val dashboardData: StateFlow<DashboardData> = _dashboardData.asStateFlow()
    
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()
    
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    
    suspend fun login(email: String, password: String): User? {
        return try {
            _isLoading.value = true
            val user = db.userDao().login(email, password)
            if (user != null && user.isApproved) {
                _currentUser.value = user
                _error.value = null
                user
            } else {
                _error.value = if (user == null) "Invalid credentials" else "Account not approved"
                null
            }
        } catch (e: Exception) {
            _error.value = "Login error: ${e.message}"
            null
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun registerUser(email: String, password: String, name: String, isAdmin: Boolean = false): Boolean {
        return try {
            _isLoading.value = true
            val existingUser = db.userDao().getUserByEmail(email)
            if (existingUser != null) {
                _error.value = "Email already registered"
                return false
            }
            val user = User(
                email = email,
                password = password,
                name = name,
                isAdmin = isAdmin,
                isApproved = isAdmin
            )
            db.userDao().insertUser(user)
            _error.value = null
            true
        } catch (e: Exception) {
            _error.value = "Registration error: ${e.message}"
            false
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun approveUser(userId: Int) {
        try {
            _isLoading.value = true
            db.userDao().approveUser(userId)
            _error.value = null
        } catch (e: Exception) {
            _error.value = "Approval error: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun addIncome(income: Income) {
        try {
            _isLoading.value = true
            db.incomeDao().insertIncome(income)
            _error.value = null
            updateDashboard()
        } catch (e: Exception) {
            _error.value = "Failed to add income: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun addExpense(expense: Expense) {
        try {
            _isLoading.value = true
            db.expenseDao().insertExpense(expense)
            _error.value = null
            updateDashboard()
        } catch (e: Exception) {
            _error.value = "Failed to add expense: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun addEMI(emi: EMI) {
        try {
            _isLoading.value = true
            db.emiDao().insertEMI(emi)
            _error.value = null
            updateDashboard()
        } catch (e: Exception) {
            _error.value = "Failed to add EMI: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun makeEMIPayment(emiId: Int) {
        try {
            _isLoading.value = true
            val emi = db.emiDao().getEMIById(emiId)
            if (emi != null) {
                val newPaidMonths = emi.paidMonths + 1
                if (newPaidMonths >= emi.totalMonths) {
                    db.emiDao().completeEMI(emiId)
                } else {
                    val nextDate = emi.nextPaymentDate + (30 * 24 * 60 * 60 * 1000L)
                    db.emiDao().makeEMIPayment(emiId, nextDate)
                }
                _error.value = null
                updateDashboard()
            }
        } catch (e: Exception) {
            _error.value = "Failed to make EMI payment: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun deleteEMI(emi: EMI) {
        try {
            _isLoading.value = true
            db.emiDao().deleteEMI(emi)
            _error.value = null
            updateDashboard()
        } catch (e: Exception) {
            _error.value = "Failed to delete EMI: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun addBorrow(borrow: Borrow) {
        try {
            _isLoading.value = true
            val updatedBorrow = borrow.copy(
                remainingAmount = borrow.amount,
                totalWithInterest = borrow.amount + borrow.interestAmount
            )
            db.borrowDao().insertBorrow(updatedBorrow)
            _error.value = null
            updateDashboard()
        } catch (e: Exception) {
            _error.value = "Failed to add borrow: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun returnBorrow(borrowId: Int) {
        try {
            _isLoading.value = true
            val borrow = db.borrowDao().getBorrowById(borrowId)
            if (borrow != null) {
                val totalAmount = borrow.amount + borrow.interestAmount
                db.borrowDao().markBorrowAsReturned(borrowId, totalAmount, System.currentTimeMillis())
                _error.value = null
                updateDashboard()
            }
        } catch (e: Exception) {
            _error.value = "Failed to return borrow: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun deleteBorrow(borrow: Borrow) {
        try {
            _isLoading.value = true
            db.borrowDao().deleteBorrow(borrow)
            _error.value = null
            updateDashboard()
        } catch (e: Exception) {
            _error.value = "Failed to delete borrow: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    private suspend fun updateDashboard() {
        val totalIncome = db.incomeDao().getCurrentMonthTotalIncome() ?: 0.0
        val totalExpense = db.expenseDao().getCurrentMonthTotalExpense() ?: 0.0
        val emiCount = db.emiDao().getCurrentMonthEMICount()
        val emiAmount = db.emiDao().getCurrentMonthEMIAmount() ?: 0.0
        val pendingBorrow = db.borrowDao().getTotalPendingBorrowAmount() ?: 0.0
        
        var totalEMIRemaining = 0.0
        db.emiDao().getActiveEMIs().collect { emis ->
            emis.forEach { emi ->
                val remainingMonths = emi.totalMonths - emi.paidMonths
                if (remainingMonths > 0) {
                    totalEMIRemaining += remainingMonths * emi.monthlyAmount
                }
            }
        }
        
        _dashboardData.value = DashboardData(
            totalIncome = totalIncome,
            totalExpense = totalExpense,
            emiCount = emiCount,
            emiAmount = emiAmount,
            pendingBorrow = pendingBorrow,
            totalEMIRemaining = totalEMIRemaining
        )
    }
    
    fun clearError() {
        _error.value = null
    }
}

data class DashboardData(
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val emiCount: Int = 0,
    val emiAmount: Double = 0.0,
    val pendingBorrow: Double = 0.0,
    val totalEMIRemaining: Double = 0.0
)