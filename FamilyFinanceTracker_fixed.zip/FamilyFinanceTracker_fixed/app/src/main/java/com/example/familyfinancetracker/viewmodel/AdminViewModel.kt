package com.example.familyfinancetracker.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.familyfinancetracker.data.AppDatabase
import com.example.familyfinancetracker.data.User
import kotlinx.coroutines.launch

class AdminViewModel : ViewModel() {

    private val _pendingUsers = MutableLiveData<List<User>>(emptyList())
    val pendingUsers: LiveData<List<User>> = _pendingUsers

    private val _approvedUsers = MutableLiveData<List<User>>(emptyList())
    val approvedUsers: LiveData<List<User>> = _approvedUsers

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    fun loadPendingUsers(db: AppDatabase) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                db.userDao().getPendingApprovals().collect { users ->
                    _pendingUsers.value = users
                }
            } catch (e: Exception) {
                _error.value = "Error loading users: ${e.message}"
            }
            _isLoading.value = false
        }
    }

    fun approveUser(db: AppDatabase, userId: Int) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                db.userDao().approveUser(userId)
                loadPendingUsers(db)
            } catch (e: Exception) {
                _error.value = "Error approving user: ${e.message}"
            }
            _isLoading.value = false
        }
    }

    fun rejectUser(db: AppDatabase, userId: Int) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                db.userDao().rejectUser(userId)
                loadPendingUsers(db)
            } catch (e: Exception) {
                _error.value = "Error rejecting user: ${e.message}"
            }
            _isLoading.value = false
        }
    }

    fun getAllUsers(db: AppDatabase) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                db.userDao().getAllUsers().collect { users ->
                    _approvedUsers.value = users.filter { it.isApproved }
                }
            } catch (e: Exception) {
                _error.value = "Error loading users: ${e.message}"
            }
            _isLoading.value = false
        }
    }

    fun clearError() {
        _error.value = null
    }
}