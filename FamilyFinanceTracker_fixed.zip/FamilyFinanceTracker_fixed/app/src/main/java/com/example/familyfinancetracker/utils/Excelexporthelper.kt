package com.example.familyfinancetracker.utils

import android.content.Context
import android.os.Environment
import android.widget.Toast
import com.example.familyfinancetracker.data.Expense
import com.example.familyfinancetracker.data.Income
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class ExcelExportHelper(private val context: Context) {

    fun exportToExcel(incomes: List<Income>, expenses: List<Expense>, fileName: String = "finance_report"): File? {
        return try {
            val folder = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "FamilyFinance/Excel")
            if (!folder.exists()) folder.mkdirs()

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val file = File(folder, "${fileName}_${timestamp}.csv")

            val outputStream = FileOutputStream(file)
            val writer = java.io.OutputStreamWriter(outputStream)

            // Write CSV header
            writer.write("Type,Category,Description,Amount,Date,User\n")

            incomes.forEach { income ->
                writer.write("Income,${income.category},${income.source},${income.amount},${DateUtils.formatDate(income.date)},${income.userName}\n")
            }

            expenses.forEach { expense ->
                writer.write("Expense,${expense.category},${expense.description},${expense.amount},${DateUtils.formatDate(expense.date)},${expense.userName}\n")
            }

            writer.close()
            outputStream.close()

            Toast.makeText(context, "Excel exported: ${file.name}", Toast.LENGTH_SHORT).show()
            file
        } catch (e: Exception) {
            Toast.makeText(context, "Export failed: ${e.message}", Toast.LENGTH_SHORT).show()
            null
        }
    }

    fun shareFile(file: File) {
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Report"))
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to share: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}