package com.example.familyfinancetracker.utils

object Constants {

    // Database
    const val DATABASE_NAME = "family_finance_db"
    const val DATABASE_VERSION = 2

    // Shared Preferences
    const val PREF_NAME = "FamilyFinancePrefs"
    const val KEY_USER_ID = "user_id"
    const val KEY_USER_EMAIL = "user_email"
    const val KEY_USER_NAME = "user_name"
    const val KEY_IS_ADMIN = "is_admin"
    const val KEY_IS_LOGGED_IN = "is_logged_in"
    const val KEY_THEME = "theme"
    const val KEY_NOTIFICATIONS = "notifications"

    // API Keys (if any)
    const val BASE_URL = "https://api.example.com/"

    // Categories
    val INCOME_CATEGORIES = listOf(
        "Salary", "Business", "Investment", "Freelance", "Rental", "Other"
    )

    val EXPENSE_CATEGORIES = listOf(
        "Grocery", "Electricity", "Water", "Mobile", "WiFi",
        "OTT", "School", "Van", "Insurance", "Rent",
        "Medical", "Entertainment", "Shopping", "Petrol", "Other"
    )

    val EMI_TYPES = listOf(
        "Personal", "Home", "Car", "Education", "Other"
    )

    val PAYMENT_METHODS = listOf(
        "Cash", "UPI", "Credit Card", "Debit Card", "Net Banking", "Other"
    )

    // Notification IDs
    const val NOTIFICATION_ID_EMI = 1001
    const val NOTIFICATION_ID_BORROW = 1002
    const val NOTIFICATION_ID_REMINDER = 1003
    const val NOTIFICATION_ID_SUMMARY = 1004

    // Request Codes
    const val REQUEST_CAMERA = 100
    const val REQUEST_GALLERY = 101
    const val REQUEST_PERMISSION = 102
    const val REQUEST_EXPORT = 103

    // Date Formats
    const val DATE_FORMAT = "dd MMM yyyy"
    const val DATE_TIME_FORMAT = "dd MMM yyyy, hh:mm a"
    const val TIME_FORMAT = "hh:mm a"
    const val MONTH_YEAR_FORMAT = "MMM yyyy"

    // File Names
    const val BACKUP_FILE_PREFIX = "backup_"
    const val EXPORT_FILE_PREFIX = "finance_report_"
    const val PDF_EXTENSION = ".pdf"
    const val CSV_EXTENSION = ".csv"
    const val JSON_EXTENSION = ".json"

    // Default Values
    const val DEFAULT_EMI_DAY = 1
    const val DEFAULT_INTEREST_RATE = 0.0
    const val DEFAULT_PROCESSING_FEE = 0.0
}