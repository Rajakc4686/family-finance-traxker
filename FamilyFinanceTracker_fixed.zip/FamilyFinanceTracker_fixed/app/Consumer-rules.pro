# This file contains consumer rules for libraries
# If you are building an AAR, these rules will be applied to consuming apps

# Keep Room database classes
-keep class androidx.room.** { *; }
-keep class * extends androidx.room.RoomDatabase

# Keep Data classes for serialization
-keep class com.example.familyfinancetracker.data.** { *; }