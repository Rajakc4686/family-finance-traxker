# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# Keep Room classes
-keep class androidx.room.** { *; }
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.**

# Keep Gson classes
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapter

# Keep Parcelable
-keep class * implements android.os.Parcelable { *; }

# Keep ViewModel and LiveData
-keep class androidx.lifecycle.** { *; }

# Keep Data classes
-keep class com.example.familyfinancetracker.data.** { *; }

# Optimizations
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep class names
-keep class com.example.familyfinancetracker.** { *; }
-dontwarn com.example.familyfinancetracker.**